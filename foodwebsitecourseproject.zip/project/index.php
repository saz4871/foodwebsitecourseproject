<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirect to HH Page</title>
    <script type="text/javascript">
        window.onload = function() {
            window.location.href = "getStatus.php";  // Redirect to hh.html on page load
        };
    </script>
</head>
<body>
    <h1>Redirecting...</h1>
</body>
</html>
